var searchData=
[
  ['aligned_20allocation_1',['Aligned Allocation',['../group__aligned.html',1,'']]]
];
