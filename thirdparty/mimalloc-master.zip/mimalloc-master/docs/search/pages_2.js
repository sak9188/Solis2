var searchData=
[
  ['overriding_20malloc_326',['Overriding Malloc',['../overrides.html',1,'']]]
];
