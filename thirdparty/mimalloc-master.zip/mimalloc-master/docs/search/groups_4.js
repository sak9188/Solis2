var searchData=
[
  ['heap_20allocation_318',['Heap Allocation',['../group__heap.html',1,'']]],
  ['heap_20introspection_319',['Heap Introspection',['../group__analysis.html',1,'']]]
];
